import 'dart:async';
import 'dart:convert';
import 'package:flutter/services.dart' show rootBundle;
import 'package:vokabeltrainer_app/core/latlon.dart';

class StationLoader {
  static Future<List<LatLon>> loadStationsFromCSV(String assetPath) async {
    final csvString = await rootBundle.loadString(assetPath);
    final lines = LineSplitter.split(csvString);
    final List<LatLon> stations = [];
    bool isFirst = true;

    for (final line in lines) {
      if (isFirst) {
        isFirst = false;
        continue;
      }
      final columns = line.split(';');
      if (columns.length < 2) continue;
      try {
        final lat = double.parse(columns[columns.length - 2].replaceAll(',', '.'));
        final lon = double.parse(columns[columns.length - 1].replaceAll(',', '.'));
        stations.add(LatLon(lat, lon));
      } catch (_) {}
    }
    return stations;
  }
}
