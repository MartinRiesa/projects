import 'package:flutter/material.dart';
import 'package:vokabeltrainer_app/core/latlon.dart';
import '../core/station_loader.dart';
import 'widgets/germany_map_with_progress_interactive.dart';
import 'station_info_dialog.dart';
import 'package:vokabeltrainer_app/core/station_description_provider.dart';

class MapScreenProgress extends StatefulWidget {
  final int completedLevels;
  final int nextLevel;
  final ImageProvider? levelImage;

  const MapScreenProgress({
    Key? key,
    required this.completedLevels,
    required this.nextLevel,
    this.levelImage,
  }) : super(key: key);

  @override
  State<MapScreenProgress> createState() => _MapScreenProgressState();
}

class _MapScreenProgressState extends State<MapScreenProgress> {
  late Future<List<LatLon>> _stationsFuture;
  List<ImageProvider?>? levelImages; // Du brauchst alle Level-Bilder (z.B. aus Asset, Network...)

  @override
  void initState() {
    super.initState();
    _stationsFuture = StationLoader.loadStationsFromCSV(
      'assets/Stationenbeschreibung-englisch.csv',
    );
    // Beispiel: Dummy, du musst eigene Logik/Bilder liefern!
    // levelImages = List.generate(100, (i) => widget.levelImage);
  }

  // Diese Funktion lädt das Bild für eine Station; du kannst sie anpassen!
  ImageProvider? getImageForStation(int index) {
    // Beispiel: Immer das gleiche Bild wie für aktuelles Level:
    return widget.levelImage;
    // Für echte Apps: Wähle aus Asset/Network basierend auf index!
  }

  // Diese Funktion lädt die Beschreibung für eine Station:
  Future<String?> getDescriptionForStation(int index) {
    // Meist Level=Index+1:
    return StationDescriptionProvider.getExplanation(index + 1);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Deutschlandkarte – Fortschritt')),
      body: FutureBuilder<List<LatLon>>(
        future: _stationsFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError || !snapshot.hasData) {
            return const Center(child: Text('Fehler beim Laden der Stationen.'));
          }
          final stations = snapshot.data!;

          return SingleChildScrollView(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                const SizedBox(height: 18),
                GermanyMapWithProgressInteractive(
                  stations: stations,
                  completedLevels: widget.completedLevels,
                  nextLevel: widget.nextLevel,
                  assetPath: 'assets/images/germany_map.png',
                  mapScale: 1.15,
                  onStationTap: (int index) async {
                    // Lade Bild & Beschreibung:
                    final img = getImageForStation(index);
                    final desc = await getDescriptionForStation(index);

                    showDialog(
                      context: context,
                      builder: (_) => StationInfoDialog(
                        stationIndex: index,
                        image: img,
                        description: desc,
                      ),
                    );
                  },
                ),
                const SizedBox(height: 30),
              ],
            ),
          );
        },
      ),
    );
  }
}
