import 'package:flutter/material.dart';
import 'package:vokabeltrainer_app/ui/language_selection_screen.dart';
import 'package:vokabeltrainer_app/ui/main_menu_screen.dart'; // Passe ggf. an

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Vokabeltrainer',
      debugShowCheckedModeBanner: false,
      initialRoute: '/',
      routes: {
        '/': (context) => const LanguageSelectionScreen(),
        '/main': (context) => const MainMenuScreen(), // Passe ggf. an
        // Hier kannst du weitere Screens ergänzen:
        // '/karte': (context) => const MapScreenProgress(),
        // '/level': (context) => const LevelScreen(),
      },
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
    );
  }
}
