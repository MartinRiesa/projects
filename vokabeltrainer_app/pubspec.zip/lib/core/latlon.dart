class LatLon {
  final double lat;
  final double lon;
  const LatLon(this.lat, this.lon);
}
