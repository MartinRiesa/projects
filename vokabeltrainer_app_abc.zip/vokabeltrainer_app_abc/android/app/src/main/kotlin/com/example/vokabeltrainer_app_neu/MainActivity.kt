package com.example.vokabeltrainer_app_neu

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
